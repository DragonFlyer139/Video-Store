<html>
<head><title>Video Store</title></head>
<body>
You are not logged in. Please <a href="admin_login.php">log in</a>.
</body>
</html>