<html>
<head><title>Video Store</title></head>
<body>
You are not logged in. Please <a href="member_login.php">log in</a> or <a href="signup.php">sign up</a>.
</body>
</html>