<html>
<head><title>Login Page</title></head>
<body>
<h3>Enter Login Information</h3>

<form action="form_target.php" method="post">
	Username: <input type="text" name = "Username"><br>
	Password: <input type = "password" name = "Password"><br>
	<input type = "Submit" value = "Login">
</form>

</body>
</html>